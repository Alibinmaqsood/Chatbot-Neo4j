import aiml
from tkinter import *
from nltk import word_tokenize,pos_tag
from py2neo import *

def tokenization(line):
    token = word_tokenize(line)
    tags = pos_tag(token)
    print("line:", line)
    print("tokens : ", token)
    print("parts of speach : ", tags)
    return tags

def send():
    w = open("story.txt", "a+")
    w.writelines(popup.get())
    w.close()
    feedback = kernel.respond(popup.get())
    alert(feedback)

def neo4j():
    userInput = popup.get()
    tokens = word_tokenize(userInput)
    pos_tag_list = pos_tag(tokens)

    nouns = []
    verbs = []

    print(pos_tag_list)
    for tuple in pos_tag_list:
        if tuple[1] == "NN" or tuple[1] == "NNS" or tuple[1] == "NNP" or tuple[1] == "NNPS":
            nouns.append(tuple[0])

        elif tuple[1] == "IN" or tuple[1] == "JJ" or tuple[1] == "VB" or tuple[1] == "VBD" or tuple[1] == "VBG" or \
                tuple[1] == "VBN" or tuple[1] == "VBP" or tuple[1] == "VBZ":
            verbs.append(tuple[0])

    graph = Graph(password="1234")

    i = 0

    while i < len(nouns):
        graph.run("MERGE(p:Person{name: '" + nouns[i] + "'})")
        i = i + 1

    i = 0

    graph.run("MATCH(p1:Person{name: '" + nouns[i] + "'})"
            "MATCH(p2:Person{name: '" + nouns[i + 1] + "'})"
            "CREATE(p1)-[:Relationship{name:'" + verbs[-1] + "'}]" + "->(p2)")

def Quit():
    file = open("tokens.txt", "w")
    file.write("List of Nouns :\n")
    w = open("story.txt", "r")
    p = w.read()
    w.close()
    i = tokenization(p)
    for k in i:
        file.write("   ")
        file.writelines(k)
    file.close()
    quit()

def message_field_delete():
    message_field.delete(first=0, last=1000)
    message_field2.delete(first=0, last=1000)
    w = open("story.txt", "r")
    p = w.read()
    w.close()

def alert(re):
    message_field2.insert(0, re)



kernel = aiml.Kernel()
kernel.learn("startup.xml")
kernel.respond("load aiml a")
feedback = "Nothing"

root = Tk()
root.title("Story Bot")
root.geometry("400x500")
popup = StringVar()
popup1 = StringVar()
title = Label(root, text="YOUR OWN STORY BOT", fg="#000000", bg="#ffffb3", relief="solid", font={"calibri", 18, "bold"})
title.pack(fill=BOTH, pady=1, padx=1)

message_label = Label(root, text="Type Message", fg="#000000", bg="#6666ff", relief="solid", font={"calibri", 16})
message_label.pack(pady=10, padx=10)
message_label.place(x=40, y=60, height=30, width=300)

message_field = Entry(root, textvar=popup, width=100)
message_field.place(x=90, y=90, height=30, width=200)

message_field2 = Entry(root, width=100)
message_field2.place(x=90, y=300, height=30, width=200)

message_label = Label(root, text="Bot Response", fg="#000000", bg="#999966", relief="solid", font={"calibri", 16})
message_label.pack(pady=10, padx=10)
message_label.place(x=40, y=270, height=30, width=300)

quit_button = Button(root, text="Quit Chat", width=10, bg="#ff0000", fg="#000000", command=Quit)
quit_button.place(x=140, y=370, height=30, width=100)

next_button = Button(root, text="Next Message", width=10, bg="#6699ff", fg="#000000", command=message_field_delete)
next_button.place(x=250, y=150, height=30, width=100)

send_button = Button(root, text="Send Message", width=10, bg="#00ff00", fg="#000000", command=send)
send_button.place(x=80, y=150, height=30, width=100)

neo_button = Button(root, text="NEO4J INPUT", width=10, bg="pink", fg="#000000", command=neo4j)
neo_button.place(x=150, y=200, height=30, width=100)

root.mainloop()